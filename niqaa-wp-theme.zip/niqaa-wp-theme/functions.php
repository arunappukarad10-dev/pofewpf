<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'NIQAA_DEFAULT_PHONE', '+966536496183' );

function niqaa_setup() {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'style', 'script' ) );
}
add_action( 'after_setup_theme', 'niqaa_setup' );

function niqaa_assets() {
	wp_enqueue_style(
		'niqaa-fonts',
		'https://fonts.googleapis.com/css2?family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&display=swap',
		array(),
		null
	);
	wp_enqueue_style( 'niqaa-style', get_stylesheet_uri(), array( 'niqaa-fonts' ), '1.0' );
}
add_action( 'wp_enqueue_scripts', 'niqaa_assets' );

/** إعدادات القالب: تخصيص > إعدادات صفحة الهبوط */
function niqaa_customize( $wp_customize ) {
	$wp_customize->add_section( 'niqaa_section', array(
		'title'    => 'إعدادات صفحة الهبوط',
		'priority' => 20,
	) );

	$fields = array(
		'niqaa_phone'    => array( 'رقم الجوال (بصيغة دولية)', NIQAA_DEFAULT_PHONE ),
		'niqaa_brand'    => array( 'اسم النشاط', 'نِقاء' ),
		'niqaa_headline' => array( 'العنوان الرئيسي', 'تنظيف شامل يلمّع بيتك' ),
		'niqaa_subline'  => array( 'النص التعريفي', 'فريق موثوق يصلك في نفس اليوم. حجز خلال دقيقتين ونتكفّل بالباقي.' ),
		'niqaa_wa_text'  => array( 'نص رسالة واتساب الجاهزة', 'السلام عليكم، أرغب بخدمة تنظيف.' ),
	);

	foreach ( $fields as $id => $data ) {
		$wp_customize->add_setting( $id, array(
			'default'           => $data[1],
			'sanitize_callback' => 'wp_kses_post',
		) );
		$wp_customize->add_control( $id, array(
			'label'   => $data[0],
			'section' => 'niqaa_section',
			'type'    => 'text',
		) );
	}

	$wp_customize->add_setting( 'niqaa_hero_image', array( 'sanitize_callback' => 'esc_url_raw' ) );
	$wp_customize->add_control(
		new WP_Customize_Image_Control( $wp_customize, 'niqaa_hero_image', array(
			'label'   => 'صورة القسم الرئيسي',
			'section' => 'niqaa_section',
		) )
	);
}
add_action( 'customize_register', 'niqaa_customize' );

function niqaa_opt( $key, $fallback = '' ) {
	return get_theme_mod( $key, $fallback );
}

function niqaa_phone_raw() {
	return preg_replace( '/[^0-9+]/', '', niqaa_opt( 'niqaa_phone', NIQAA_DEFAULT_PHONE ) );
}

function niqaa_whatsapp_link() {
	$num  = ltrim( niqaa_phone_raw(), '+' );
	$text = rawurlencode( niqaa_opt( 'niqaa_wa_text', 'السلام عليكم، أرغب بخدمة تنظيف.' ) );
	return 'https://wa.me/' . $num . '?text=' . $text;
}

function niqaa_hero_url() {
	$custom = niqaa_opt( 'niqaa_hero_image' );
	return $custom ? $custom : get_template_directory_uri() . '/assets/hero-cleaning.jpg';
}

function niqaa_icon_whatsapp() {
	return '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>';
}

function niqaa_icon_phone() {
	return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/></svg>';
}
